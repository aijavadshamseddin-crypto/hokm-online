import 'package:flutter/material.dart';
import 'game_engine.dart';

void main() => runApp(const HokmApp());

class HokmApp extends StatelessWidget {
  const HokmApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'حکم آنلاین',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF092A22),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFD6B56D),
          brightness: Brightness.dark,
        ),
        fontFamily: 'Roboto',
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(
            children: [
              const SizedBox(height: 26),
              const Text('حُکم آنلاین',
                  style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900,
                      color: Color(0xFFF1D79B))),
              const SizedBox(height: 8),
              const Text('چهار بازیکن • دو تیم • یک رقابت دوستانه',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white70)),
              const Spacer(),
              Container(
                width: 190,
                height: 190,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFF124638),
                  border: Border.all(color: const Color(0xFFD6B56D), width: 2),
                  boxShadow: const [
                    BoxShadow(color: Colors.black38, blurRadius: 24, spreadRadius: 2)
                  ],
                ),
                child: const Center(
                  child: Icon(Icons.style, size: 92, color: Color(0xFFF1D79B)),
                ),
              ),
              const Spacer(),
              _MenuButton(
                label: 'شروع بازی آزمایشی',
                icon: Icons.play_arrow_rounded,
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const TablePage())),
              ),
              const SizedBox(height: 12),
              _MenuButton(
                label: 'ساخت میز خصوصی (به‌زودی)',
                icon: Icons.lock_outline,
                enabled: false,
                onTap: () {},
              ),
              const SizedBox(height: 12),
              _MenuButton(
                label: 'پیدا کردن بازیکن آنلاین (به‌زودی)',
                icon: Icons.public,
                enabled: false,
                onTap: () {},
              ),
              const Spacer(),
              const Text('نسخه آزمایشی ۰.۱',
                  style: TextStyle(color: Colors.white38, fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}

class _MenuButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  final bool enabled;

  const _MenuButton({
    required this.label,
    required this.icon,
    required this.onTap,
    this.enabled = true,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 56,
      child: FilledButton.icon(
        onPressed: enabled ? onTap : null,
        icon: Icon(icon),
        label: Text(label, textAlign: TextAlign.center),
        style: FilledButton.styleFrom(
          backgroundColor: const Color(0xFFD6B56D),
          foregroundColor: const Color(0xFF17352C),
          disabledBackgroundColor: Colors.white12,
          disabledForegroundColor: Colors.white38,
          textStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        ),
      ),
    );
  }
}

class TablePage extends StatefulWidget {
  const TablePage({super.key});

  @override
  State<TablePage> createState() => _TablePageState();
}

class _TablePageState extends State<TablePage> {
  late HokmGame game;
  PlayingCard? selected;

  @override
  void initState() {
    super.initState();
    game = HokmGame.newGame();
    game.chooseTrump(0, Suit.spades); // demo-only default trump
  }

  void playCard(PlayingCard card) {
    setState(() {
      selected = card;
      game.playForDemo(card);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('میز حکم آزمایشی'),
        backgroundColor: Colors.transparent,
        actions: [
          IconButton(
            tooltip: 'شروع دوباره',
            onPressed: () => setState(() {
              game = HokmGame.newGame();
              game.chooseTrump(0, Suit.spades);
              selected = null;
            }),
            icon: const Icon(Icons.refresh),
          )
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 8),
            const _PlayerBadge(name: 'بازیکن شمال', detail: 'هم‌تیمی شما'),
            const Spacer(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: const [
                _PlayerBadge(name: 'بازیکن غرب', detail: 'حریف'),
                _CenterTable(),
                _PlayerBadge(name: 'بازیکن شرق', detail: 'حریف'),
              ],
            ),
            const SizedBox(height: 14),
            Text('کارت‌های شما: ${game.hand.length}',
                style: const TextStyle(color: Colors.white70)),
            const SizedBox(height: 8),
            SizedBox(
              height: 112,
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                scrollDirection: Axis.horizontal,
                itemCount: game.hand.length,
                separatorBuilder: (_, __) => const SizedBox(width: 5),
                itemBuilder: (context, index) {
                  final card = game.hand[index];
                  return GestureDetector(
                    onTap: () => playCard(card),
                    child: _CardTile(card: card, selected: selected == card),
                  );
                },
              ),
            ),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18),
              child: Text(
                selected == null
                    ? 'برای نمایش آزمایشی، یکی از کارت‌ها را انتخاب کنید.'
                    : 'کارت ${selected!.label} انتخاب شد. این میز فعلاً نمایشی و تک‌نفره است.',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white70),
              ),
            ),
            const SizedBox(height: 18),
          ],
        ),
      ),
    );
  }
}

class _PlayerBadge extends StatelessWidget {
  final String name;
  final String detail;
  const _PlayerBadge({required this.name, required this.detail});

  @override
  Widget build(BuildContext context) => Column(
    children: [
      const CircleAvatar(
        radius: 23,
        backgroundColor: Color(0xFFD6B56D),
        child: Icon(Icons.person, color: Color(0xFF17352C)),
      ),
      const SizedBox(height: 4),
      Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
      Text(detail, style: const TextStyle(fontSize: 11, color: Colors.white54)),
    ],
  );
}

class _CenterTable extends StatelessWidget {
  const _CenterTable();

  @override
  Widget build(BuildContext context) => Container(
    width: 112,
    height: 112,
    decoration: BoxDecoration(
      shape: BoxShape.circle,
      color: const Color(0xFF15513E),
      border: Border.all(color: const Color(0xFFD6B56D), width: 2),
    ),
    child: const Center(
      child: Text('حکم', style: TextStyle(
        fontSize: 25, fontWeight: FontWeight.w900, color: Color(0xFFF1D79B))),
    ),
  );
}

class _CardTile extends StatelessWidget {
  final PlayingCard card;
  final bool selected;
  const _CardTile({required this.card, required this.selected});

  @override
  Widget build(BuildContext context) {
    final red = card.suit == Suit.hearts || card.suit == Suit.diamonds;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      width: 65,
      margin: EdgeInsets.only(top: selected ? 0 : 10, bottom: selected ? 10 : 0),
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFDF7),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: selected ? const Color(0xFFD6B56D) : Colors.black26,
          width: selected ? 3 : 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(card.rankLabel,
              style: TextStyle(fontWeight: FontWeight.w900,
                  color: red ? Colors.red.shade700 : Colors.black87)),
          const Spacer(),
          Center(child: Text(card.suit.symbol,
              style: TextStyle(fontSize: 25,
                  color: red ? Colors.red.shade700 : Colors.black87))),
        ],
      ),
    );
  }
}
