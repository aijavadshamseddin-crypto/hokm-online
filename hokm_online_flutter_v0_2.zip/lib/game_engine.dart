import 'dart:math';

enum Suit { spades, hearts, diamonds, clubs }

extension SuitInfo on Suit {
  String get symbol => switch (this) {
        Suit.spades => '♠',
        Suit.hearts => '♥',
        Suit.diamonds => '♦',
        Suit.clubs => '♣',
      };

  String get persianName => switch (this) {
        Suit.spades => 'پیک',
        Suit.hearts => 'دل',
        Suit.diamonds => 'خشت',
        Suit.clubs => 'گشنیز',
      };
}

class PlayingCard {
  final Suit suit;
  final int rank; // 2..14; 11=J, 12=Q, 13=K, 14=A

  const PlayingCard(this.suit, this.rank) : assert(rank >= 2 && rank <= 14);

  String get rankLabel => switch (rank) {
        11 => 'J',
        12 => 'Q',
        13 => 'K',
        14 => 'A',
        _ => '$rank',
      };

  String get label => '$rankLabel ${suit.persianName}';

  @override
  bool operator ==(Object other) =>
      other is PlayingCard && other.suit == suit && other.rank == rank;

  @override
  int get hashCode => Object.hash(suit, rank);

  @override
  String toString() => '$rankLabel${suit.symbol}';
}

class PlayedCard {
  final int seat;
  final PlayingCard card;
  const PlayedCard({required this.seat, required this.card});
}

class TrickResult {
  final int winnerSeat;
  final int winningTeam;
  final List<PlayedCard> cards;

  const TrickResult({
    required this.winnerSeat,
    required this.winningTeam,
    required this.cards,
  });
}

class HokmRuleException implements Exception {
  final String message;
  const HokmRuleException(this.message);
  @override
  String toString() => message;
}

/// Local four-player Hokm rules engine.
///
/// Seats are clockwise: 0, 1, 2, 3.
/// Partners are opposite: team 0 = seats 0 and 2; team 1 = seats 1 and 3.
/// This is a local engine. An online release must run the authoritative
/// validation on a trusted server, not on the players' phones.
class HokmGame {
  static const int playerCount = 4;
  static const int cardsPerPlayer = 13;
  static const int tricksToWinRound = 7;

  final List<List<PlayingCard>> hands;
  final List<PlayingCard> _undealt;
  final int _dealStartSeat;
  final int dealerSeat;
  final int hakemSeat;

  /// Compatibility accessor for the first local/demo seat.
  List<PlayingCard> get hand => hands[0];

  Suit? trump;
  int currentSeat;
  int tricksTeam0 = 0;
  int tricksTeam1 = 0;
  int completedTricks = 0;
  int? roundWinnerTeam;

  final List<PlayedCard> currentTrick = [];
  final List<TrickResult> trickHistory = [];

  bool get isRoundOver => roundWinnerTeam != null;
  Suit? get leadSuit =>
      currentTrick.isEmpty ? null : currentTrick.first.card.suit;

  HokmGame._({
    required this.hands,
    required List<PlayingCard> undealt,
    required int dealStartSeat,
    required this.dealerSeat,
    required this.hakemSeat,
    required this.currentSeat,
  })  : _undealt = undealt,
        _dealStartSeat = dealStartSeat;

  factory HokmGame.newGame({
    int? seed,
    int dealerSeat = 3,
    int hakemSeat = 0,
  }) {
    _validateSeat(dealerSeat);
    _validateSeat(hakemSeat);

    final deck = freshDeck(seed: seed);
    final hands = List.generate(playerCount, (_) => <PlayingCard>[]);
    final dealStartSeat = (dealerSeat + 1) % playerCount;
    var seat = dealStartSeat;

    // Standard Hokm sequence: five cards to each player first.
    for (var i = 0; i < 20; i++) {
      hands[seat].add(deck[i]);
      seat = (seat + 1) % playerCount;
    }

    for (final hand in hands) {
      hand.sort(_compareForDisplay);
    }

    return HokmGame._(
      hands: hands,
      undealt: deck.skip(20).toList(),
      dealStartSeat: dealStartSeat,
      dealerSeat: dealerSeat,
      hakemSeat: hakemSeat,
      currentSeat: hakemSeat,
    );
  }

  static void _validateSeat(int seat) {
    if (seat < 0 || seat >= playerCount) {
      throw ArgumentError.value(seat, 'seat', 'باید بین ۰ تا ۳ باشد');
    }
  }

  static int teamOf(int seat) {
    _validateSeat(seat);
    return seat.isEven ? 0 : 1;
  }

  static List<PlayingCard> freshDeck({int? seed}) {
    final cards = <PlayingCard>[
      for (final suit in Suit.values)
        for (var rank = 2; rank <= 14; rank++) PlayingCard(suit, rank),
    ];
    cards.shuffle(seed == null ? Random() : Random(seed));
    return cards;
  }

  List<PlayingCard> legalCardsFor(int seat) {
    _validateSeat(seat);
    final hand = hands[seat];
    if (currentTrick.isEmpty) return List.unmodifiable(hand);

    final requiredSuit = leadSuit!;
    final matching = hand.where((c) => c.suit == requiredSuit).toList();
    return List.unmodifiable(matching.isNotEmpty ? matching : hand);
  }

  void chooseTrump(int seat, Suit suit) {
    _ensureActive();
    if (trump != null) {
      throw const HokmRuleException('خال حکم قبلاً انتخاب شده است.');
    }
    if (seat != hakemSeat) {
      throw const HokmRuleException('فقط حاکم می‌تواند خال حکم را انتخاب کند.');
    }
    trump = suit;

    // Once the hakem has chosen trump, deal the remaining eight cards
    // to every player, continuing the same clockwise dealing order.
    var seat = _dealStartSeat;
    for (final card in _undealt) {
      hands[seat].add(card);
      seat = (seat + 1) % playerCount;
    }
    _undealt.clear();

    for (final hand in hands) {
      hand.sort(_compareForDisplay);
    }
  }

  /// Demo-only helper used by the starter UI. It removes a card from seat 0
  /// without simulating the other three players. Real games must use playCard.
  void playForDemo(PlayingCard card) {
    if (hands[0].remove(card)) {
      // The demo UI only visualizes local card selection.
    }
  }

  /// Plays one card for the current player.
  /// Returns null until the fourth card; then returns the completed trick.
  TrickResult? playCard(int seat, PlayingCard card) {
    _ensureActive();
    if (trump == null) {
      throw const HokmRuleException('ابتدا حاکم باید خال حکم را انتخاب کند.');
    }
    if (seat != currentSeat) {
      throw const HokmRuleException('نوبت این بازیکن نیست.');
    }
    if (!hands[seat].contains(card)) {
      throw const HokmRuleException('این کارت در دست بازیکن نیست.');
    }
    if (!legalCardsFor(seat).contains(card)) {
      throw HokmRuleException(
        'باید از خال ${leadSuit!.persianName} بازی کنید.',
      );
    }

    hands[seat].remove(card);
    currentTrick.add(PlayedCard(seat: seat, card: card));

    if (currentTrick.length < playerCount) {
      currentSeat = (currentSeat + 1) % playerCount;
      return null;
    }

    final completed = List<PlayedCard>.unmodifiable(currentTrick);
    final winnerSeat = _findTrickWinner(completed);
    final winningTeam = teamOf(winnerSeat);

    if (winningTeam == 0) {
      tricksTeam0++;
    } else {
      tricksTeam1++;
    }

    completedTricks++;
    final result = TrickResult(
      winnerSeat: winnerSeat,
      winningTeam: winningTeam,
      cards: completed,
    );
    trickHistory.add(result);
    currentTrick.clear();
    currentSeat = winnerSeat;

    if (tricksTeam0 >= tricksToWinRound) {
      roundWinnerTeam = 0;
    } else if (tricksTeam1 >= tricksToWinRound) {
      roundWinnerTeam = 1;
    } else if (completedTricks == 13) {
      roundWinnerTeam = tricksTeam0 > tricksTeam1 ? 0 : 1;
    }

    return result;
  }

  int _findTrickWinner(List<PlayedCard> cards) {
    final ledSuit = cards.first.card.suit;
    var best = cards.first;

    for (final candidate in cards.skip(1)) {
      if (_beats(candidate.card, best.card, ledSuit, trump!)) {
        best = candidate;
      }
    }
    return best.seat;
  }

  static bool _beats(
    PlayingCard candidate,
    PlayingCard currentBest,
    Suit ledSuit,
    Suit trumpSuit,
  ) {
    final candidateTrump = candidate.suit == trumpSuit;
    final bestTrump = currentBest.suit == trumpSuit;

    if (candidateTrump && !bestTrump) return true;
    if (!candidateTrump && bestTrump) return false;
    if (candidateTrump && bestTrump) {
      return candidate.rank > currentBest.rank;
    }

    final candidateFollows = candidate.suit == ledSuit;
    final bestFollows = currentBest.suit == ledSuit;

    if (candidateFollows && !bestFollows) return true;
    if (!candidateFollows) return false;
    return candidate.rank > currentBest.rank;
  }

  void _ensureActive() {
    if (isRoundOver) {
      throw const HokmRuleException('این دور تمام شده است.');
    }
  }

  static int _compareForDisplay(PlayingCard a, PlayingCard b) {
    final suitOrder = a.suit.index.compareTo(b.suit.index);
    return suitOrder != 0 ? suitOrder : a.rank.compareTo(b.rank);
  }
}
